// EAMain/EAEntryPointMain.inl contains C++ code but it exposes the application entry point with C linkage.

#include "EAMain/EAEntryPointMain.inl"
#include "EATest/EASTLNewOperatorGuard.inl"

/////////////////////////////////////////////////////////////////////////////
// Copyright (c) Electronic Arts Inc. All rights reserved.
/////////////////////////////////////////////////////////////////////////////


#include "EASTLTest.h"
#include <EASTL/bonus/intrusive_slist.h>
#include <EABase/eabase.h>



// Template instantations.
// These tell the compiler to compile all the functions for the given class.
//template class intrusive_slist<int>;



int TestIntrusiveSList()
{
	int nErrorCount = 0;

	// As of this writing, we don't yet have a completed intrusive_slist implementation.
	// The interface is in place but the implementation hasn't been done yet.

	return nErrorCount;
}












